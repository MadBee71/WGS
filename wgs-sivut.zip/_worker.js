// build 1783858961
async function handleKickCallback(request) {
  const params = new URL(request.url).search;
  const target = "com.streamer.app://kick-callback" + params;
  return new Response(`<!doctype html>
<html><head><meta charset="utf-8"><title>Kick-kirjautuminen</title></head>
<body style="font-family:sans-serif;text-align:center;padding-top:80px;background:#0e0e10;color:#fff;">
  <p>Kirjaudutaan sisään...</p>
  <p><a href="${target}" style="display:inline-block;padding:14px 28px;background:#53FC18;color:#000;font-weight:bold;text-decoration:none;border-radius:8px;font-size:1.1em;">Palaa sovellukseen</a></p>
  <p style="opacity:0.6;font-size:0.9em;">Jos et siirry automaattisesti, paina yllä olevaa nappia.</p>
  <script>location.replace(${JSON.stringify(target)});</script>
</body></html>`, { headers: { "Content-Type": "text/html; charset=utf-8" } });
}

// Twitchin implicit grant palauttaa tokenin URL-FRAGMENTTINA (#access_token=...), joka EI
// KOSKAAN lähde selaimesta palvelimelle (fragmentit ovat puhtaasti selainpuolisia) — tämä
// sivu ei siis voi lukea sitä request.url:sta niin kuin Kickin code/state query-parametrit.
// Sen sijaan palautetaan static HTML+JS joka lukee window.location.hash:n SELAIMESSA ja
// pomppaa sen sellaisenaan eteenpäin custom schemeen.
async function handleTwitchCallback(request) {
  return new Response(`<!doctype html>
<html><head><meta charset="utf-8"><title>Twitch-kirjautuminen</title></head>
<body style="font-family:sans-serif;text-align:center;padding-top:80px;background:#0e0e10;color:#fff;">
  <p>Kirjaudutaan sisään...</p>
  <p><a id="link" href="#" style="display:inline-block;padding:14px 28px;background:#9146FF;color:#fff;font-weight:bold;text-decoration:none;border-radius:8px;font-size:1.1em;">Palaa sovellukseen</a></p>
  <p style="opacity:0.6;font-size:0.9em;">Jos et siirry automaattisesti, paina yllä olevaa nappia.</p>
  <script>
    var target = "com.streamer.app://twitch-callback" + window.location.hash;
    document.getElementById("link").href = target;
    location.replace(target);
  </script>
</body></html>`, { headers: { "Content-Type": "text/html; charset=utf-8" } });
}

async function handleKickToken(request, env) {
  let body;
  try {
    body = await request.json();
  } catch {
    return new Response(JSON.stringify({ error: "invalid_json" }), {
      status: 400, headers: { "Content-Type": "application/json" },
    });
  }
  const { code, code_verifier, redirect_uri } = body;
  if (!code || !code_verifier || !redirect_uri) {
    return new Response(JSON.stringify({ error: "missing_params" }), {
      status: 400, headers: { "Content-Type": "application/json" },
    });
  }

  const form = new URLSearchParams();
  form.set("grant_type", "authorization_code");
  form.set("client_id", env.KICK_CLIENT_ID);
  form.set("client_secret", env.KICK_CLIENT_SECRET);
  form.set("code", code);
  form.set("redirect_uri", redirect_uri);
  form.set("code_verifier", code_verifier);

  const kickResp = await fetch("https://id.kick.com/oauth/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: form.toString(),
  });
  const text = await kickResp.text();
  return new Response(text, {
    status: kickResp.status,
    headers: { "Content-Type": "application/json" },
  });
}

async function handleKickRefresh(request, env) {
  let body;
  try {
    body = await request.json();
  } catch {
    return new Response(JSON.stringify({ error: "invalid_json" }), {
      status: 400, headers: { "Content-Type": "application/json" },
    });
  }
  const { refresh_token } = body;
  if (!refresh_token) {
    return new Response(JSON.stringify({ error: "missing_refresh_token" }), {
      status: 400, headers: { "Content-Type": "application/json" },
    });
  }

  const form = new URLSearchParams();
  form.set("grant_type", "refresh_token");
  form.set("client_id", env.KICK_CLIENT_ID);
  form.set("client_secret", env.KICK_CLIENT_SECRET);
  form.set("refresh_token", refresh_token);

  const kickResp = await fetch("https://id.kick.com/oauth/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: form.toString(),
  });
  const text = await kickResp.text();
  return new Response(text, {
    status: kickResp.status,
    headers: { "Content-Type": "application/json" },
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/kick-callback" && request.method === "GET") {
      return handleKickCallback(request);
    }
    if (url.pathname === "/twitch-callback" && request.method === "GET") {
      return handleTwitchCallback(request);
    }
    if (url.pathname === "/api/kick-token" && request.method === "POST") {
      return handleKickToken(request, env);
    }
    if (url.pathname === "/api/kick-refresh" && request.method === "POST") {
      return handleKickRefresh(request, env);
    }

    return env.ASSETS.fetch(request);
  },
};
